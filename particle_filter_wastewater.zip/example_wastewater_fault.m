%% Programmed by:
% Diego Andres Alvarez Marin (diegotorquemada@gmail.com)
% Universidad Nacional de Colombia at Manizales, February 29, 2012

%% Updated by:
% Eva Kenyeres (kenyeva2000@gmail.com)
% University of Pannonia, January 19, 2023

%Note: similar to example_wastewater.m, but for the fault detection experiments

%% clear memory, screen, and close all figures
clear, clc, close all;
%% Parameter definition
global res o o_max F M alfa_ipf p_m tau S0 R mu_m K_s alfa C k_d dt tsim N sigma_u nx V Rv S0v nx xh0 Neff Ns k

m=1;

tsim=400;  %day
dt=0.01;
time=dt:dt:tsim;  %day
N=floor(tsim/dt);

V=125; %m^3
F=809.06;  %m^3/day

tauv=V./F;

S0=4000; %mg COD/L
R=1.5; %it has the best performance with C=1.5
mu_m=1.0; %1/day
K_s=100; %mg COD/L
alfa=0.5; %mg MLSS/mg COD
C=1.5; %concentration factor (intermediate value, less than C_max=(R+1)/(R+w))
k_d=0.028; %1/day

%% Fault generation 
M=50; %sliding window of the decision function

%Analysis of fault-signal ratio

% fault_list=zeros(N,4); %impact sensor fault
% fault_list(round(N/16):end,1)=330;    % 5% fault
% fault_list(round(N/16):end,2)=660;    % 10% fault
% fault_list(round(N/16):end,3)=990;   % 15% fault
% fault_list(round(N/16):end,4)=1320;   % 20% fault
% fault_list(5500:end,:)=0; 

%Tuning of sliding window (M)
fault=zeros(N,1); %bias fault
fault(round(N/16):end)=330;
fault(5500:end)=0; 

% fault=zeros(N,1);   %impact fault
% fault(round(N/16):end)=990;
% fault(round(N/16+100):end)=0;
% 
% M_list=[10 20 50 100]


%% Steps on more actuators (F,R,S0)
F=randn(N,1)*0+809.06;
tauv=V./F;
Rv=randn(N,1)*0+1.5;
S0v=randn(N,1)*0+4000; %feed concentration
part=12;

F(round(1*N/part):end)=F(round(1*N/part):end)+(400-809.06);
S0v(round(2*N/part):end)=S0v(round(2*N/part):end)+(5000-4000);  
Rv(round(3*N/part):end)=Rv(round(3*N/part):end)+(1-1.5);
F(round(4*N/part):end)=F(round(4*N/part):end)+(260-400);
Rv(round(5*N/part):end)=Rv(round(5*N/part):end)+(0.5-1);
S0v(round(6*N/part):end)=S0v(round(6*N/part):end)+(3000-5000);
Rv(round(7*N/part):end)=Rv(round(7*N/part):end)+(1.6-0.5);
F(round(8*N/part):end)=F(round(8*N/part):end)+(900-260);
S0v(round(9*N/part):end)=S0v(round(9*N/part):end)+(4000-3000);
F(round(10*N/part):end)=F(round(10*N/part):end)+(809.06-900);
Rv(round(11*N/part):end)=Rv(round(11*N/part):end)+(1.5-1.6);

%% Process equation x[k] = sys(k, x[k-1], u[k]);
% x: [S1, X1, S2, X2]
% u: noise
nx = 4;  % number of states

%% Observation equation y[k] = obs(k, x[k], v[k]);
ny = 1;                                           % number of observations
obs = @(k, xk, vk) xk(2) + vk;                  % (returns column vector)
%% PDF of process noise and noise generator function
nu = 4;                                           % size of the vector of process noise
sigma_u = sqrt(100);
p_sys_noise   = @(u) normpdf(u, 0, sigma_u);
gen_sys_noise = @(u) normrnd(0, sigma_u);         % sample from p_sys_noise (returns column vector)
%% PDF of observation noise and noise generator function
nv = 1;                                           % size of the vector of observation noise
sigma_v = 140 %sqrt(625);
p_obs_noise   = @(v) normpdf(v, 0, sigma_v);
gen_obs_noise = @(v) normrnd(0, sigma_v);         % sample from p_obs_noise (returns column vector)
%% Initial PDF
% p_x0 = @(x) normpdf(x, 0,sqrt(10));             % initial pdf
gen_x0 = @(x) normrnd([4000 6400 4000 6600], sqrt(100));  %=sigma_u?             % sample from p_x0 (returns column vector)
%% Transition prior PDF p(x[k] | x[k-1])
% (under the suposition of additive process noise)
% p_xk_given_xkm1 = @(k, xk, xkm1) p_sys_noise(xk - sys(k, xkm1, 0));
%% Observation likelihood PDF p(y[k] | x[k])
% (under the suposition of additive process noise)
p_yk_given_xk = @(k, yk, xk) p_obs_noise(yk - obs(k, xk, 0));
%% Number of time steps
T = N;
%% Separate memory space
x = zeros(nx,T);  y = zeros(ny,T);
u = zeros(nu,T);  v = zeros(nv,T);
%% Simulate system
xh0 = [4000 6400 4000 6600];              % initial state
u(:,1) = [0 0 0 0];                               % initial process noise
v(:,1) = gen_obs_noise(sigma_v);          % initial observation noise
x(:,1) = xh0;
y(:,1) = obs(1, xh0, v(:,1));

o_max=1;

L=zeros(T,o_max);
d=zeros(T,o_max);
res=zeros(T,o_max);

for o=1:o_max
%fault=fault_list(:,o); %sensitivity analysis of fault, M
%M=M_list(o);
for k = 2:T
   
    tau=V./F(k-1);
    R=Rv(k-1);
    S0=S0v(k-1);
   
   % here we are basically sampling from p_xk_given_xkm1 and from p_yk_given_xk
   u(1,k) = gen_sys_noise();              % simulate process noise
   u(2,k) = gen_sys_noise();
   u(3,k) = gen_sys_noise();
   u(4,k) = gen_sys_noise();
   v(:,k) = gen_obs_noise();              % simulate observation noise
   x(:,k) = sys1(k, x(:,k-1), [0 0 0 0]); %u(:,k));  % simulate state (we added noise on the input tau)
   y(:,k) = obs(k, x(:,k),v(:,k))+fault(k);   % simulate observation (we have noise when we measure)
end
% Note: generating measured data by the state-space model

figure
hold on;
plot(time,x')
plot(time,y')
legend ('S1','X1','S2','X2')
xlabel('time [day]')
ylabel('Concentration [mg/L]')

%% Separate memory
T=round(N/5);  %time steps in the PF

alfa_ipf_list=0.15;  %for tuning the IPF
p_m_list=0;

e_av=zeros(nx,size(alfa_ipf_list,2));  %place for average error for different alfa_ipf and p_m parameters during tuning the IPF

p_m=0;  %the chosen parameters
alfa_ipf=0.2;

% for m=1:size(p_m_list,2)   %number of p_m_list or alfa_ipf_list 
%     p_m=p_m_list(m);
%     alfa_ipf=alfa_ipf_list(m);
%     e=zeros(nx,10);
%     
for l=1:1  %number of running the simulation (S)
xh = zeros(nx, T); xh(:,1) = xh0;
yh = zeros(ny, T); yh(:,1) = obs(1, xh0, 0);
pf.k               = 1;                   % initial iteration number
pf.Ns              = 30;                 % number of particles
pf.w               = zeros(pf.Ns, T);     % weights
pf.particles       = zeros(nx, pf.Ns, T); % particles
pf.gen_x0          = gen_x0;              % function for sampling from initial pdf p_x0
pf.p_yk_given_xk   = p_yk_given_xk;       % function of the observation likelihood PDF p(y[k] | x[k])
pf.gen_sys_noise   = gen_sys_noise;       % function for generating system noise
%pf.p_x0 = p_x0;                          % initial prior PDF p(x[0])
%pf.p_xk_given_ xkm1 = p_xk_given_xkm1;   % transition prior PDF p(x[k] | x[k-1])
%% Estimate state


sys = @sys1;
tic

for k = 2:T
   
   fprintf('Iteration = %d/%d\n',k,T)
    
   tau=V./F(k-1);
   R=Rv(k-1);
   S0=S0v(k-1);
    
   % state estimation
   pf.k = k;
   %[xh(:,k), pf] = particle_filter(sys, y(:,k), pf, 'multinomial_resampling');
   [xh(:,k), pf] = particle_filter(sys, y(:,k), pf, 'systematic_resampling');   
 
   % filtered observation
   yh(:,k) = obs(k, xh(:,k), 0);
   
%% Decision function [Kadirkamanathan, 2010, p.5. (16)-(18) Eq.]

for i=1:Ns
    L(k,o)=L(k,o)+pf.p_yk_given_xk(k, y(:,k), pf.particles(:,i,k));
end
L(k,o)=L(k,o)/Ns;
if k-M+1>0
d(k,o)=-sum(log(L(k-M+1:k,o)))/M;
end
end

hxx=sort(d((M+1):T,o),'descend');
hx=hxx(round(0.02*(size(hxx,1))));

if M==10 %the chosen contraints according to the 98% confidence
   h=6.8702;
elseif M==20
    h=6.7145; 
elseif M==50
    h=6.5680; 
elseif M==100
    h=6.4987 ;

end
hox(o)=h;
end
end

%% Plots
figure
subplot(3,1,1)
plot(dt:dt:T*dt,F(1:T),'b')
ylabel('F [m^3/day]')
xlabel('Time [day]')
ylim([300 900]);
subplot(3,1,2)
plot(dt:dt:T*dt,S0v(1:T),'b')
ylabel('S_0 [mg COD/L]')
xlabel('Time [day]')
ylim([3000 6000]);
subplot(3,1,3)
plot(dt:dt:T*dt,fault(1:T),'r')
ylabel('Fault [mg MLSS/L]')
xlabel('Time [day]')
ylim([0 1500]);

%% 
figure
subplot(1,2,1)
yyaxis left
histogram(d((M+1):T,1),100)
xlabel('-d_k')
ylabel('Histogram of -d_k','Fontweight','bold')
hold on
yyaxis right
[f1 xi1]=ksdensity(d((M+1):T,1))
plot(xi1,f1,'-r','LineWidth',2)
ax = gca;
ax.YAxis(1).FontWeight='bold'
ax.YAxis(2).Color = 'r';
ax.YAxis(2).FontWeight='bold'
ax(1).YAxis(2).LineWidth = 1.5;
ax(1).YAxis(1).LineWidth = 1.5;
xlabel('-d_k')
ylabel('Fitted Probability Density','Fontweight','bold')
ylim([0 4.5]);
subplot(1,2,2)
[f2 xi2]=ksdensity(d((M+1):T),'Function','cdf');
plot(xi2,f2,'-r','LineWidth',1.5)
hold on
yyaxis right
ax = gca();
ax.YAxis(2).Color = 'none';
yyaxis left
ax = gca();
ax.YAxis(1).Color = 'r';
ax.YAxis(1).FontWeight='bold'
ax.YAxis(1).LineWidth = 1.5;
xlabel('-d_k')
ylabel('Cumulative Density','Fontweight','bold')
xline(h,'b','h','LineWidth',1.5,'LabelOrientation', 'horizontal');

%%

figure
% subplot(4,1,1)
% plot(dt:dt:T*dt,fault(1:T));
% xlabel('Time [day]');
% ylabel('Sensor fault [mg MLSS/L]');
% %title('Fault signal')
%subplot(4,1,1)
subplot(2,2,1)
plot(dt:dt:T*dt,d(1:T,1),dt:dt:T*dt,ones(T,1)*hox(1),'r');
xlabel('Time [day]');
ylabel('-dk [-]');
ylim([5 inf]);
legend('-dk (5% fault)','threshold')
%legend('-dk (M=10)','threshold')

%subplot(4,1,2)
subplot(2,2,2)
%plot(dt:dt:T*dt,d(:,1));
plot(dt:dt:T*dt,d(1:T,2),dt:dt:T*dt,ones(T,1)*hox(2),'r');
xlabel('Time [day]');
ylabel('-dk [-]');
ylim([5 inf]);
legend('-dk (10% fault)','threshold')
%legend('-dk (M=20)','threshold')
%title('Operation with sensor fault')
%subplot(4,1,3)
subplot(2,2,3)
%plot(dt:dt:T*dt,d);
plot(dt:dt:T*dt,d(1:T,3),dt:dt:T*dt,ones(T,1)*hox(3),'r');
xlabel('Time [day]');
ylabel('-dk [-]');
ylim([5 inf]);
legend('-dk (15% fault)','threshold')
%legend('-dk (M=50)','threshold')
%title('Operation with sensor fault')
%subplot(4,1,4)
subplot(2,2,4)
%plot(dt:dt:T*dt,d);
plot(dt:dt:T*dt,d(1:T,4),dt:dt:T*dt,ones(T,1)*hox(4),'r');
xlabel('Time [day]');
ylabel('-dk [-]');
ylim([5 inf]);
legend('-dk (20% fault)','threshold')
%legend('-dk (M=100)','threshold')
%title('Operation with sensor fault')

% Analysing the number of resamplings
for i=1:o_max
res1(i)=sum(res(1:N/16-1,i));
res2(i)=sum(res(N/16:5500,i));
res3(i)=sum(res(5500:end,i));
end
TTT=toc
%% Error calculation [Yin, 2015, p.6. (30) Eq.]

for i=1:nx
    e(i,l)=1/T*sum(abs(x(i,1:T)-xh(i,:))); %average error by time
end
disp(e);


for i=1:nx
    e_av(i,m)=1/10*sum(e(i,:)); %average error for more simulation (if there are more)
end
%end
%% Make plots of the evolution of the density

xi = 1:20:T;  %plot in 20 time step
xiplot=0.01:0.2:T*0.01;


%% plot of the state vs estimated state by the particle filter vs particle paths
xi = 1:1:T;  
xiplot=xi.*dt;
y_name=['S1';'X1';'S2';'X2'];

for j=1:nx  %for every state
for i = 1:size(xi,2)
   
   Q = quantile(pf.particles(j,:,xi(i)),[0.25,0.5,0.75]);
   xhq25(j,xi(i))=Q(1); %lower quartile
   xhmed(j,xi(i))=Q(2); %median
   xhq75(j,xi(i))=Q(3); %upper quartile
end
end

figure (4)
sgtitle('State vs estimated state by the particle filter vs particle paths','FontSize',14);

for j=1:nx
   subplot(2,2,j);
   %figure(j)
hold on;
h1 = plot(xiplot,squeeze(pf.particles(j,:,xi))','y.'); %all of the particles, state X1
h2 = plot(xiplot,x(j,xi),'b','LineWidth',2); %real
%h3 = plot(xiplot,xh(j,xi),'r','LineWidth',4); %expected value
%h4 = plot(xiplot,xhmode(j,xi),'g','LineWidth',4); %modus
h5=plot(xiplot,xhq25(j,xi),'g','LineWidth',1); %lower quartile
h6=plot(xiplot,xhmed(j,xi),'k','LineWidth',1); %median
h7=plot(xiplot,xhq75(j,xi),'g','LineWidth',1); %hihger quartile


if j==2
   %legend([h2; h3; h4; h1],'real state','mean of estimated state','mode of estimated state','particle paths', 'Location', 'northeast');
   legend([h2;h5;h6;h7;h1],'real state','lower quartile','median','upper quartile','particle paths', 'Location', 'northeast'); 
end 
xlabel('time [day]')
ylabel(y_name(j,:))
end
 
%% Plot of the real vs. estimated states and measurement by the particle filter
figure 
xi = 1:1:T;  
xiplot=xi.*dt;
subplot(3,1,1:2)
plot(dt:dt:T*dt,y(:,1:T),'b', dt:dt:T*dt,yh,'r');
hold on
plot(xiplot,x(2,xi),'-m','LineWidth',1.5)
legend('Measurement','Estimated state','Real state'); %y: real (with noise), yh: estimated (without noise)
%title('Observation vs filtered observation by the particle filter','FontSize',14);
xlabel('Time [day]')
ylabel('X_1 [mg MLSS/L]')
subplot(3,1,3)
plot(dt:dt:T*dt,fault(1:T),'r')
ylabel('Fault [mg MLSS/L]')
xlabel('Time [day]')
legend('5% fault')
ylim([0 1500]);


return;

% figure
% subplot(3,1,1)
% plot(time,F,'r')
% ylabel('F [m^3/day]')
% xlabel('time [day]')
% subplot(3,1,2)
% plot(time,R,'r')
% ylabel('R [-]')
% xlabel('time [day]')
% subplot(3,1,3)
% plot(time,S0v,'r')
% ylabel('S0 [mg COD/L]')
% xlabel('time [day]')
