%% Parameter ranges (wastewater)

% Reference:
% [1] Nelson, M. I., & Bradshaw-Hajek, B. H. (2020). An analysis of organic carbon removal in a two-reactor cascade with recycle and a two-reactor step-feed cascade with recycle. Asia-Pacific Journal of Chemical Engineering, 15(1), e2392. 

%% Programmed by:
% Eva Kenyeres (kenyeva2000@gmail.com)
% University of Pannonia, January 19, 2023

%% Parameter definition
global S0_cs tau S0 R mu_m K_s alfa C k_d N w n C_max C_lista R_list S0_list V

tauv=randn(N,1)*0.02+0.1545;   %generating noise on tau 
tauv(round(N/4):end)=tauv(round(N/4):end)+(0.1425-0.1545);     %generating step on tau 

S0=4000 %mg COD/L
mu_m=1.0 %1/day
K_s=100 %mg COD/L
alfa=0.5 %mg MLSS/mg COD
k_d=0.028 %1/day

V=125 %m3


%For change:
R=1.5; %recycle factor [0.5, 1, 1.5]
C=1.5; %concentration factor  [1, 1.5]
w=0.1   %wastage factor
n=1  % volume ratio of the two reactor [0.5, 1, 2]

R_max=(1-w*C)/(C-1);   %p.6 eq.2
C_max=(R+1)/(R+w);  %p.6 eq.1

%practically w=0.1

%if w=0, then we assume ideal circumstances, we can get theoretical maximum of R

S0_cs=S0/K_s;       %S0*
k_dcs=k_d/mu_m;     %k_d*

R_list=[0.5 1 1.5];
S0_list=[3000 4000 5000]; 
S0_cs_list=S0_list/K_s;
tau_min=zeros(3,3);


% Changing C and R
% for i=1:size(R_lista,2)
%     R=R_lista(i);
%     C_max=(R+1)/(R+w);
%     C_lista=[1 1.5 C_max];
%     for j=1:size(C_lista,2)
%         C=C_lista(j);
%         
%         b_SRC=(4*C*n+(1-n)^2)*R^2+2*(2*C*n+(1-n)^2)*R+(1-n)^2;  %p.10
%         tau_min(j,i)=(1+S0_cs)/2/(S0_cs-(1+S0_cs)*k_dcs)*(((1+n)*(1+R)-sqrt(b_SRC))/n); %p.11 eq.11
%         
%     end
% end
  
% Changing S0 and R
for i=1:size(R_list,2)
    R=R_list(i);
    
    for j=1:size(S0_cs_list,2)
        S0_cs=S0_cs_list(j);
        
        b_SRC=(4*C*n+(1-n)^2)*R^2+2*(2*C*n+(1-n)^2)*R+(1-n)^2;  %p.10
        tau_min(j,i)=(1+S0_cs)/2/(S0_cs-(1+S0_cs)*k_dcs)*(((1+n)*(1+R)-sqrt(b_SRC))/n); %p.11 eq.11
        
    end
end

F_max=V./tau_min; %calculating maximal flow rate (m^3/day)