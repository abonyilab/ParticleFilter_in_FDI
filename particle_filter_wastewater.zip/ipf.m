function [xk,wk]=ipf(xk,wk,wkm1,pf,yk, alfa_ipf, p_m)

global Neff Ns nx k

%% State-space model of the wastewater treatment process
%
% Usage:
% [xk,wk]=ipf(xk,wk,wkm1,pf,yk, alfa_ipf, p_m)
%
% Inputs:
% xk = estimated state vector after the correction step at time k
% wk = normalized weights after the correction step at time k
% wkm1 = normalized weights after the correction step at time k-1
% pf.p_yk_given_xk    = function handle of the observation likelihood PDF p(y[k] | x[k])
% alfa_ipf = parameter of the crossover step
% p_m = parameter of the mutation step
%
% Outputs:
% xk   = new estimated state vector at time k (after modification by the genetic
% algorithm)
% wk = weights of the new particles
%
% Note: x = [S1 X1 S2 X2]
% 
% Reference:
%   [1] Shen Yin and Xiangping Zhu. Intelligent particle filter and its application to fault de-
%       tection of nonlinear system. IEEE Transactions on Industrial Electronics, 62(6):3852–
%       3861, 2015.
%% Programmed by:
% Eva Kenyeres (kenyeva2000@gmail.com)
% University of Pannonia, January 19, 2023

%%
% Classification of the particles into large and small weight groups
A=[wk xk'];
A=sortrows(A,1,'descend');
W_t=A(round(Neff),1);
%alfa_ipf=0.8;
%p_m=0.04;
CL=[]; %low weight particles
CH=[]; %high weight particles

for i=1:Ns
    if A(i,1)<=W_t
        CL=[CL;A(i,:)];
    else
        CH=[CH;A(i,:)];
    end
end

%Crossover step
for i=1:size(CL,1)
    j=randi([1,size(CH,1)]);
    CL(i,[2:nx+1])=alfa_ipf*CL(i,[2:nx+1])+(1-alfa_ipf)*CH(j,[2:nx+1]);


%Mutation step

    r_l=rand(1);
    if r_l<=p_m
        CL(i,[2:nx+1])=2*CH(j,[2:nx+1])-CL(i,[2:nx+1]);
    end 
end

wkn=[CL(:,1);CH(:,1)];
xkn=[CL(:,[2:nx+1]);CH(:,[2:nx+1])]';

%Recalculation of the weights

for i=1:Ns
    wkn(i) = wkm1(i) * pf.p_yk_given_xk(k, yk, xkn(:,i));
end

%Normalization of the weights
wkn=wkn./sum(wkn);

%Output
wk=wkn;
xk=xkn;
