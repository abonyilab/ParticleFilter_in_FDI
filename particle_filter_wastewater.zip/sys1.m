function xk=sys1(k, xkm1, uk)

global S0 R mu_m K_s alfa C k_d dt tsim N tau

%% State-space model of the wastewater treatment process
%
% Usage:
% xk = sys1(k, xkm1, uk)
%
% Inputs:
% k = iteration number
% xkm1 = state vector at time k-1
% uk = system noise vector at time k
%
% Outputs:
% xk   = state vector at time k
%
% Note: x = [S1 X1 S2 X2]
% 
% Reference:
%   [1] Mark Ian Nelson and Bronwyn H. Bradshaw-Hajek. An analysis of organic carbon
%       removal in a two-reactor cascade with recycle and a two-reactor step-feed cascade
%       with recycle. Asia-Pacific Journal of Chemical Engineering, 15(1):e2392, 2020. e2392
%       apj.2392.
%% Programmed by:
% Eva Kenyeres (kenyeva2000@gmail.com)
% University of Pannonia, January 19, 2023

%%

xk(1) = (1-dt/tau-dt*R/tau)*xkm1(1)+dt*R/tau*xkm1(3)-dt*mu_m*xkm1(1)*xkm1(2)/alfa/(K_s+xkm1(1))+dt*S0/tau + uk(1);
xk(2) = (1-dt/tau-dt*R/tau-dt*k_d)*xkm1(2)+dt/tau*R*C*xkm1(4)+dt*mu_m*xkm1(1)*xkm1(2)/(K_s+xkm1(1)) + uk(2);
xk(3) = dt*(1+R)/tau*xkm1(1)+(1-dt/tau*(1+R))*xkm1(3)-dt*mu_m*xkm1(3)*xkm1(4)/alfa/(K_s+xkm1(3)) + uk(3);
xk(4) = (1-dt/tau*(1+R)-dt*k_d)*xkm1(4)+dt/tau*(1+R)*xkm1(2)+dt*mu_m*xkm1(3)*xkm1(4)/(K_s+xkm1(3)) + uk(4);
xk=xk';